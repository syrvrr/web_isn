      <!-- Interactive Slider v2 -->
      <div class="interactive-slider-v7" style="height: 184px;">
        <div class="container">
            <h1>Layanan</h1>
            <p>PT. Infomedia Solusi Net</p>
        </div>
    </div>
    <!-- End Interactive Slider v2 -->
  
   <!--Blog Post-->
   <div class="container content">
              
                    <div class="blog-img">
                        <div class="carousel slide carousel-v1" id="myCarousel">
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img alt="" src="<?php echo base_url(); ?>assets/img-temp/promo/2.jpg">
                                </div>
                            </div>
                            <div class="carousel-arrow">
                                <a data-slide="prev" href="#myCarousel" class="left carousel-control">
                                    <i class="fa fa-angle-left"></i>
                                </a>
                                <a data-slide="next" href="#myCarousel" class="right carousel-control">
                                    <i class="fa fa-angle-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="blog margin-bottom-20">
                    <h2><strong><a class="text-uppercase" style="text-decoration: none; color:black !important;">System Developer</a></strong></h2>
                    <div class="blog-post-tags">
                        <ul class="list-unstyled list-inline blog-info">
                        <p>Pengembangan aplikasi untuk segala jenis kebutuhan bisnis, baik bersifat personal, perusahaan atau pun pemerintahaan. Software/Aplikasi kami dibuat dengan menggunakan metode Web Base programming, dimana program cukup dijalankan hanya dengan menggunakan browser.</p>
                            <li><i class="fa fa-calendar"></i> 09 September, 2019</li>
                            <li><i class="fa fa-pencil"></i> Andrian</li>
                        </ul>

                    </div>
                    <p></p>
                </div>
            </div>
                <!--End Blog Post-->